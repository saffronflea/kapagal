<?php
// connecting the style.css inside the functions.php
    function wd_finals5_ct_enque_styles() {
        // getting the parent dir
        wp_enqueue_style('parent-style', get_template_directory_uri() . '/style.css');
        // getting the child dir
        wp_enqueue_style( 'main-css', get_stylesheet_uri() );
        // wp_enqueue_style('main-css', get_template_directory_uri() . '/style.css');
    }
    add_action('wp_enqueue_scripts', 'wd_finals5_ct_enque_styles', 1);
?>